//Srivani Athmakur
//7-30-2022
//CS-596
//Description: This program is to define and test an object class whose instances will be used to store some batting data for a baseball player
//I prompted the user to enter the output file and output is being written in that report file in the console to show the output just to make sure that it will also print the output.
//also I have shown the output in the console(As like instructed in the program PDF).


//while opening this file please select the intellij IDEA + Windows

import java.io.File;
import java.io.FileNotFoundException;  //if input file is not found then it will through this exception
import java.io.FileWriter;
import java.io.IOException;   //input and output exception
import java.text.DecimalFormat;
import java.util.Scanner;    // it is used to get the user input

//baseball class
public class Baseball {
    public Baseball() {
    }

    public static void main(String[] args) {
        Integer numberOfPlayers = 0;  //number of players
        StringBuffer outputStringBuffer = new StringBuffer("");
        Scanner consoleScanner = new Scanner(System.in);
        System.out.println("\nWelcome to the player statistics calculator test program.\n"); //writes the output to the scanner
        System.out.println("Enter the name of your input file: "); //asks to enter the input file name from the user
        String inputFilename = consoleScanner.nextLine();
        System.out.println("Enter the name of your output file: "); //asks to enter the output file name from the user
        String outputFilename = consoleScanner.nextLine();  //scans to the console

        //using the try and catch method.

        try {                              //try is used to get input file and tries to implement the logic in it.
            File inputStream = new File(inputFilename);

            Scanner myReader;
            for(myReader = new Scanner(inputStream); myReader.hasNextLine(); numberOfPlayers = numberOfPlayers + 1) {
                Player player = new Player();
                String playerInfo = myReader.nextLine();
                player.readData(playerInfo);
                writeToBuffer(player, outputStringBuffer);
            }

            myReader.close();
        } catch (FileNotFoundException var11) {     //if try gets file then the catch method will through the exception
            System.out.println("An error occurred.");
            var11.printStackTrace();
        }

        outputStringBuffer.append("\nEnd of Program.");
        writeOutput(outputStringBuffer, outputFilename, numberOfPlayers);
    }

    public static void writeToBuffer(Player player, StringBuffer buffer) {   //used to get the string player from write buffer class
        String var10000 = player.getLastName();
        String name = var10000 + ", " + player.getFirstName() + " :";
        int spaceCount = 22 - name.length();

        String spaces;
        for(spaces = ""; spaceCount > 0; --spaceCount) {
            spaces = spaces + " ";
        }

        DecimalFormat ft = new DecimalFormat(" #.### ");    //subclass of number format that formats decimal numbers
        var10000 = ft.format((double)player.battingAverage()).toString();
        String stats = var10000 + ft.format((double)player.opsStatistic());      //buffer is a linear, finite sequence of elements of a primitive type.
        buffer.append(String.format("%s%s, %s :     ", spaces, player.getLastName(), player.getFirstName()));
        buffer.append(stats + "\n");
    }


    //output using try and catch method.

    public static void writeOutput(StringBuffer buffer, String outFilename, Integer numberOfPlayers) {
        try {
            FileWriter outputWriter = new FileWriter(outFilename);
            String headOutput = String.format("\nPlayers found in file: %d\n", numberOfPlayers);
            headOutput = headOutput + "    PLAYER NAME      :     AVERAGE    OPS\n";
            headOutput = headOutput + "--------------------------------------------\n";
            outputWriter.write(headOutput);
            outputWriter.write(buffer.toString());
            System.out.print(headOutput);
            System.out.println(buffer.toString());
            outputWriter.close();
        } catch (IOException var5) {
            System.out.println("An error occurred.");
            var5.printStackTrace();
        }

    }
}
