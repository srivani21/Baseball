//Srivani Athmakur
//7-30-2022
//CS-596
//Description: This program is to define and test an object class whose instances will be used to store some batting data for a baseball player
//I prompted the user to enter the output file and output is being written in that report file in the console to show the output just to make sure that it will also print the output.
//also I have shown the output in the console(As like instructed in the program PDF).

//while opening this file please select the intellij IDEA + Windows

import java.util.Hashtable;   //maps keys to values
import java.util.StringTokenizer;   //it will allow application to break a string into tokens

//player class with 8 elements in it
public class Player {
    private static final int PLATE_APPEARANCES = 0;
    private static final int AT_BATS = 1;
    private static final int SINGLES = 2;
    private static final int DOUBLES = 3;
    private static final int TRIPLES = 4;
    private static final int HOME_RUNS = 5;
    private static final int WALKS = 6;
    private static final int HIT_BY_PITCH = 7;
    private static final int NUMBER_OF_STATISTICS = 8;
    String firstName;
    String lastName;
    Hashtable<Integer, Integer> statistics = new Hashtable();

    Player() {
        this.firstName = "unknown";
        this.lastName = "unknown";

        for(int i = 0; i <= 7; ++i) {
            this.statistics.put(i, 0);
        }

    }

    Player(String fName, String lName, Hashtable<Integer, Integer> stats) {
        this.firstName = fName;
        this.lastName = lName;

        for(int i = 0; i <= 7; ++i) {
            this.statistics.put(i, (Integer)stats.get(i));
        }

    }

    //to read the data we are using tokenizer

    public void readData(String data) {
        if (!data.isEmpty()) {
            StringTokenizer tokenizer = new StringTokenizer(data);
            this.firstName = tokenizer.nextToken();
            this.lastName = tokenizer.nextToken();

            for(int keyIndex = 0; tokenizer.hasMoreElements(); ++keyIndex) {
                int stat = Integer.parseInt(tokenizer.nextToken());
                this.statistics.put(keyIndex, stat);
            }

        }
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public float battingAverage() {       //calculate of batting average (singles,doubles,triples and homeruns)
        float average = 0.0F;
        float hits = (float)((Integer)this.statistics.get(2) + (Integer)this.statistics.get(3) + (Integer)this.statistics.get(4) + (Integer)this.statistics.get(5));
        if (hits > 0.0F) {
            average = hits / (float)(Integer)this.statistics.get(1);
        }

        return average;
    }

    public float onBasePercentage() {
        float basePercentage = 0.0F;
        float sumOfAllHits = (float)((Integer)this.statistics.get(2) + (Integer)this.statistics.get(3) + (Integer)this.statistics.get(4) + (Integer)this.statistics.get(5) + (Integer)this.statistics.get(6) + (Integer)this.statistics.get(7));
        if (sumOfAllHits > 0.0F) {
            basePercentage = sumOfAllHits / (float)(Integer)this.statistics.get(0);
        }

        return basePercentage;
    }

    public float sluggingPercentage() {
        float slugPercentage = 0.0F;
        float weights = (float)((Integer)this.statistics.get(2) + 2 * (Integer)this.statistics.get(3) + 3 * (Integer)this.statistics.get(4) + 4 * (Integer)this.statistics.get(5));
        if (weights > 0.0F) {
            slugPercentage = weights / (float)(Integer)this.statistics.get(1);
        }

        return slugPercentage;
    }

    public float opsStatistic() {
        float statistic = this.onBasePercentage() + this.sluggingPercentage();
        return statistic;
    }
}
